#Install new package
BiocManager::install("pathview",force = TRUE)


#Load Packages

library(enrichplot)
library(tidyverse)
library(clusterProfiler)
library(org.Hs.eg.db)
library(ReactomePA)
library(RColorBrewer)
library(ggpubr)
library(pathview)

# Load WEE1 and its interactors from string DB 

gene_of_interest<- c("WEE2", "CHEK1","CDK1","CCNB1","CDC25C","CDC25B","CDK2","WEE1","CDC25A","PLK1","CABLES1")

# Convert gene symbols to Entrez IDs (For cluster profiler)

gene_entrez<-bitr(gene_of_interest,
                  fromType = "SYMBOL",
                  toType = "ENTREZID",
                  OrgDb = "org.Hs.eg.db")

entrez_id<-gene_entrez$ENTREZID

#Perform KEGG enrihcment 

kegg_results<- enrichKEGG(gene = entrez_id,
                          organism = "hsa",
                          pvalueCutoff = 0.05,
                          qvalueCutoff = 0.2)

# View top enriched pathways

result<-head(kegg_results,10)


# Perform GO Enrichment

GO_results<- enrichGO(gene = entrez_id,
                      OrgDb = "org.Hs.eg.db",
                      keyType = "ENTREZID",
                      ont = "BP",
                      pvalueCutoff = 0.05,
                      qvalueCutoff = 0.2)

#View top GO terms
results_go<- head(GO_results,10)


# Visualizing the results

barplot(kegg_results,showCategory = 10, title = "Top Kegg Pathways")
dotplot(kegg_results,showCategory=10, title="Kegg Pathway Enrichment")
barplot(GO_results,showCategory = 10, tiitle= "GO Biological Process")
dotplot(GO_results,showCategory = 10)


# Convert to a graph for visualization (Network Plot)

kegg_network<-pairwise_termsim(kegg_results)
emapplot(kegg_network, showCategory=10)

pathview(gene.data = entrez_id, pathway.id = "04110", species = "hsa")
pathview(gene.data = entrez_id, pathway.id = "04115", species = "hsa")
